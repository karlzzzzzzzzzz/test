/**
 * 定时任务入口
 * 按 CRON 表达式定时生成需求文档（随机模式，联动 random-prd skill 抽取器）
 * CRON 格式：秒 分 时 日 月 星期
 */
const cron = require('node-cron');
const { generate } = require('./generator');

// ===== 可配置项 =====
const CRON = '0 0 9 * * *'; // 每天早上 9:00 执行
// ====================

console.log(`[定时任务已启动] 表达式: ${CRON}（每天 09:00，随机模式），按 Ctrl+C 退出`);

cron.schedule(CRON, () => {
  try {
    const { filePath, drawn } = generate(); // 不传参 = 随机模式
    console.log(`[${new Date().toLocaleString('zh-CN')}] 场景：${drawn.title}（${drawn.scale}）`);
    console.log(`[${new Date().toLocaleString('zh-CN')}] 已生成: ${filePath}`);
  } catch (err) {
    console.error(`[${new Date().toLocaleString('zh-CN')}] 生成失败:`, err);
  }
});
