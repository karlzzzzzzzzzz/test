/**
 * 需求文档生成器
 * 用法：
 *   node generator.js           → 随机模式：联动 random-prd skill 抽取器，生成带随机场景的需求文档
 *   node generator.js 登录页    → 固定模式：为指定页面生成空白模板
 */
const fs = require('fs');
const path = require('path');
const { draw } = require(path.join(__dirname, '..', '.trae', 'skills', 'random-prd', 'scripts', 'pick.js'));

const OUTPUT_DIR = path.join(__dirname, 'output');
const BASELINE_PATH = path.join(__dirname, '..', 'react-app', 'src', 'docs', 'project-features.md');

/**
 * 基线对比：从 project-features.md 中按标题前缀摘录章节
 * 返回 { text, count }
 */
function extractBaseline(matchers) {
  let md;
  try {
    md = fs.readFileSync(BASELINE_PATH, 'utf-8');
  } catch {
    return { text: '> （未找到基线文档，请手动对照 react-app/src/docs/project-features.md）', count: 0 };
  }
  const lines = md.split(/\r?\n/);
  const parts = [];
  for (const matcher of matchers) {
    const start = lines.findIndex((l) => l.startsWith(matcher));
    if (start === -1) continue;
    const level = (lines[start].match(/^#+/) || ['#'])[0].length;
    let end = start + 1;
    while (end < lines.length) {
      const m = lines[end].match(/^(#+)\s/);
      if (m && m[1].length <= level) break;
      end++;
    }
    parts.push(lines.slice(start, end).join('\n').trim());
  }
  if (!parts.length) {
    return { text: '> （基线中未匹配到对应章节，请手动对照 react-app/src/docs/project-features.md）', count: 0 };
  }
  return { text: parts.join('\n\n'), count: parts.length };
}

/** 基线对比表：从摘录中提取条目（列表项优先，其次表格行）作为预填行 */
function buildCompareTable(excerpt) {
  const lines = excerpt.text.split('\n');
  let rows = lines
    .filter((l) => /^- /.test(l))
    .map((l) => l.slice(2).replace(/\|/g, '；').trim())
    .slice(0, 8);
  if (!rows.length) {
    rows = lines
      .filter((l) => /^\| /.test(l) && !/^\|[\s:|-]+\|$/.test(l))
      .map((l) => l.trim().replace(/\s*\|\s*$/, '').replace(/\|/g, '；'))
      .slice(0, 8);
  }
  if (!rows.length) rows = ['（待填写）'];
  return rows.map((b) => `| ${b} |  |  |`).join('\n');
}

// 与 random-prd skill 的「规模与复杂度硬约束」保持一致
const SCALE_SPEC = {
  小型: { rows: '4~6 行', acc: '4~5 条（≥1 条异常）', edge: '2', keys: '0 个', struct: '只改现有区块内部，不新增顶级区块' },
  中型: { rows: '8~12 行', acc: '6~8 条（≥2 条异常）', edge: '3', keys: '≤1 个', struct: '可新增 1 个顶级区块/面板' },
  大型: { rows: '14~20 行', acc: '10~12 条（≥3 条异常）', edge: '4', keys: '≤3 个', struct: '可新增完整区块 + 子状态机/新路由' },
};

/** 随机模式：按抽取到的场景生成需求文档骨架 */
function buildRandomDoc(drawn, now) {
  const date = now.toLocaleDateString('zh-CN');
  const spec = SCALE_SPEC[drawn.scale] || SCALE_SPEC.中型;
  const related = drawn.relatedPages.length
    ? `${drawn.relatedPages.join('、')}（联动模块，功能点明细必须覆盖）`
    : '无（仅主模块）';
  // 基线对比：摘录主模块 + 联动模块的基线章节
  const excerpt = extractBaseline([...drawn.baseline, ...drawn.relatedBaseline]);
  const compareTable = buildCompareTable(excerpt);
  return `# ${drawn.page} ${drawn.type} 需求文档

> 随机生成于 ${date}，由 prd-scheduler 定时任务联动 random-prd skill 创建
>
> - **主模块**：${drawn.page}（${drawn.area}）
> - **联动模块**：${related}
> - **需求类型**：${drawn.type}
> - **规模**：${drawn.scale}（功能点明细 ${spec.rows}，验收标准 ${spec.acc}，边界情况 ≥${spec.edge}，localStorage 新增 ${spec.keys}，结构自由度：${spec.struct}）
> - **约束卡**：${drawn.twists.join('；')}

## 1. 背景与目标
（待填写，2~3 句话说清解决什么问题，目标必须可衡量）

## 2. 与基线的关系

### 2.1 基线现状摘录
（自动提取自 react-app/src/docs/project-features.md，共 ${excerpt.count} 个章节）

${excerpt.text}

### 2.2 基线对比表
（逐行核对基线现状：在【变更类型】填【新增】【修改】【删除】或【不影响】，在【需求影响】说明改前/改后）

| 基线现状 | 变更类型 | 需求影响 |
|---------|---------|---------|
${compareTable}

<!-- 若涉及基线第 5 节「已知不一致点」，需求应围绕修正或利用该现状展开 -->

## 3. 页面结构
（待填写：区块列表或线框描述，标注哪些区块是新的；${drawn.scale}规模下${spec.struct}）

## 4. 功能点明细
（待填写：| 模块 | 交互 | 规则/逻辑 | 异常处理 |，共 ${spec.rows}，数值规则要具体）

| 模块 | 交互 | 规则/逻辑 | 异常处理 |
|------|------|-----------|----------|
|      |      |           |          |

## 5. 状态说明
（待填写：加载 / 空 / 错误 三态 + 边界情况 ≥${spec.edge} 个）

## 6. 非功能需求
（待填写：性能、兼容、埋点；必须体现约束卡——${drawn.twists.join('；')}）

## 7. 验收标准
（待填写：Given-When-Then 格式，共 ${spec.acc}，覆盖主干 + 异常分支）
`;
}

/** 固定模式：为指定页面生成空白模板 */
function buildDoc(pageName) {
  const now = new Date();
  const date = now.toLocaleDateString('zh-CN');
  return `# ${pageName} 需求文档

> 自动生成于 ${date}，由 prd-scheduler 定时任务创建

## 1. 背景与目标
- 为什么做这个页面（解决什么问题）：
- 目标用户是谁：
- 成功指标（如：转化率、停留时长）：

## 2. 页面概述
- 页面入口：从哪里进入（路由、按钮跳转）：
- 页面定位：列表页 / 详情页 / 表单页 / 仪表盘：
- 依赖接口和数据来源：

## 3. 页面结构（信息架构）
自上而下描述区块：
1. 顶部导航区：
2. 内容区 A（如筛选栏）：
3. 内容区 B（如数据列表）：
4. 底部操作区：

## 4. 功能点明细（核心部分）
| 模块 | 交互 | 规则/逻辑 | 异常处理 |
|------|------|-----------|----------|
| 搜索框 | 输入后回车触发 | 支持模糊搜索，长度≤50 | 无结果时显示空状态 |
| 提交按钮 | 点击 | 必填校验通过才可提交 | 接口失败 Toast 提示 |
|      |      |           |          |

## 5. 状态说明
- 加载中：骨架屏 / Loading
- 空状态：无数据时展示什么
- 错误状态：网络失败如何重试
- 边界情况：数据超长、权限不足等

## 6. 非功能需求
- 性能：首屏加载 < ___ 秒
- 兼容：浏览器 / 移动端适配范围
- 埋点：需要统计哪些事件

## 7. 验收标准
- Given 用户已登录，When 点击提交且表单合法，Then 保存成功并跳转
- Given ____________，When ____________，Then ____________
`;
}

/** 生成文档并写入 output 目录，返回 { filePath, mode, drawn } */
function generate(pageName) {
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }
  const now = new Date();
  const date = now.toISOString().slice(0, 10); // YYYY-MM-DD

  let fileName;
  let content;
  let drawn = null;
  if (pageName) {
    fileName = `需求文档-${pageName}-${date}.md`;
    content = buildDoc(pageName);
  } else {
    drawn = draw();
    fileName = `需求文档-${drawn.page}-${date}.md`;
    content = buildRandomDoc(drawn, now);
  }

  let filePath = path.join(OUTPUT_DIR, fileName);
  // 同名文件已存在时，追加时分秒避免覆盖
  if (fs.existsSync(filePath)) {
    const time = now.toTimeString().slice(0, 8).replace(/:/g, '');
    filePath = path.join(OUTPUT_DIR, fileName.replace(/\.md$/, `-${time}.md`));
  }
  fs.writeFileSync(filePath, content, 'utf-8');
  return { filePath, mode: pageName ? 'fixed' : 'random', drawn };
}

// 命令行直接运行时，立即生成一次
if (require.main === module) {
  const pageName = process.argv[2]; // 不传参 = 随机模式
  const { filePath, mode, drawn } = generate(pageName);
  if (mode === 'random') {
    console.log(`[随机模式] 场景：${drawn.title}（${drawn.scale}）`);
    console.log(`[生成完成] ${filePath}`);
  } else {
    console.log(`[固定模式] 页面：${pageName}`);
    console.log(`[生成完成] ${filePath}`);
  }
}

module.exports = { generate };
